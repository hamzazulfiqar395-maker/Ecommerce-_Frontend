export const products = [
  {
    id: 1,
    name: "Wireless Noise-Cancelling Headphones",
    price: 299.99,
    description: "Premium over-ear headphones with active noise cancellation, 30-hour battery life, and high-fidelity audio.",
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=1000&auto=format&fit=crop"
  },
  {
    id: 2,
    name: "Minimalist Leather Watch",
    price: 145.00,
    description: "Classic analog watch with a genuine leather strap and water-resistant stainless steel casing.",
    category: "Accessories",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=1000&auto=format&fit=crop"
  },
  {
    id: 3,
    name: "Ergonomic Office Chair",
    price: 199.50,
    description: "Adjustable mesh office chair with lumbar support designed for long hours of comfortable work.",
    category: "Furniture",
    image: "https://images.unsplash.com/photo-1505843490538-5133c6c7d0e1?q=80&w=1000&auto=format&fit=crop"
  },
  {
    id: 4,
    name: "Smart Fitness Tracker",
    price: 89.99,
    description: "Track your steps, heart rate, and sleep patterns with this water-resistant smart band.",
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1575311373937-040b8e1fd5b0?q=80&w=1000&auto=format&fit=crop"
  },
  {
    id: 5,
    name: "Organic Cotton T-Shirt",
    price: 24.99,
    description: "A comfortable, breathable t-shirt made from 100% organic cotton. Available in multiple colors.",
    category: "Apparel",
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=1000&auto=format&fit=crop"
  },
  {
    id: 6,
    name: "Ceramic Coffee Mug Set",
    price: 34.00,
    description: "Set of two handcrafted ceramic mugs, perfect for your morning coffee or tea.",
    category: "Home",
    image: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?q=80&w=1000&auto=format&fit=crop"
  },
  {
    id: 7,
    name: "Portable Bluetooth Speaker",
    price: 59.99,
    description: "Compact and powerful speaker with deep bass, Bluetooth 5.0, and 12 hours of playtime.",
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?q=80&w=1000&auto=format&fit=crop"
  },
  {
    id: 8,
    name: "Canvas Weekend Duffel Bag",
    price: 75.00,
    description: "Durable canvas bag with spacious interior and multiple pockets, ideal for short trips.",
    category: "Accessories",
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?q=80&w=1000&auto=format&fit=crop"
  },
  {
    id: 9,
    name: "Stainless Steel Water Bottle",
    price: 28.50,
    description: "Double-walled vacuum insulated bottle keeps drinks cold for 24 hours or hot for 12 hours.",
    category: "Home",
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?q=80&w=1000&auto=format&fit=crop"
  },
  {
    id: 10,
    name: "Aesthetic Desk Lamp",
    price: 45.00,
    description: "Modern LED desk lamp with adjustable brightness and color temperature.",
    category: "Furniture",
    image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?q=80&w=1000&auto=format&fit=crop"
  }
];
